import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars } from "@fortawesome/free-solid-svg-icons";
import Menu from "./Menu";
import "./Header.css";

const Header = (props: any) => {
  return (
    <header className="fixed z-2 w-screen">
      <div className="relative shadow backdrop-blur-lg border-b">
        <div className="px-4 md:px-48 py-4">
          <div className="flex gap-2">
            <div className="cursor-pointer md:hidden text-gray-500 p-2 shadow border rounded-lg">
              <FontAwesomeIcon
                icon={faBars}
                onClick={() => props.setMenu(!props.menu)}
              />
            </div>

            <Link
              to="/"
              className="flex items-center gap-3 max-w-44"
            >
              <span className="capitalize font-semibold text-lg w-full">
                arico shop
              </span>
            </Link>
            <Menu menu={props.menu} />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
