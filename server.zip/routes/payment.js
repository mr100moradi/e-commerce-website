const Router = require("express");
const PaymentController = require("../controllers/paymentController");
const router = new Router();

router.post("/create-transaction", PaymentController.createTransaction);
router.get("/payment-callback", PaymentController.paymentCallback);

module.exports = router;
