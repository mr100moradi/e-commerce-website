export type User = {
  id: number;
  name: string;
  lastName: string;
  email: string;
  userType: string;
  password: string;
  skills: string[];
  createdAt: Date;
};

export const users: User[] = [
  {
    id: 1,
    name: "M.Reza",
    lastName: "Hosseini",
    email: "mr99.moradi@gmail.com",
    userType: "employer",
    password: "123456",
    skills: ["HTML", "CSS", "React"],
    createdAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 2,
    name: "Ali",
    lastName: "Rezaei",
    email: "ali.rezaei@gmail.com",
    userType: "employee",
    password: "123456",
    skills: ["Node.js", "Express", "MongoDB"],
    createdAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 3,
    name: "Sina",
    lastName: "Kazemi",
    email: "sina.kazemi@gmail.com",
    userType: "employee",
    password: "123456",
    skills: ["React", "Node.js", "Express", "MongoDB"],
    createdAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 4,
    name: "Darius",
    lastName: "Najafi",
    email: "darius.najafi@gmail.com",
    userType: "employee",
    password: "123456",
    skills: ["React", "React Native"],
    createdAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 5,
    name: "hassaan",
    lastName: "Khalili",
    email: "hassaan.Khalili@gmail.com",
    userType: "employee",
    password: "123456",
    skills: ["Python", "Machine Learning", "AI", "Data Science"],
    createdAt: new Date("2025-09-17T00:00:00Z"),
  },
];
