import { useContext, useEffect, useState } from "react";
import "./Product.css";
import { MyContext } from "../../pages/MyContext";
import { products } from "../../data/products";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCodeCompare, faHeart } from "@fortawesome/free-solid-svg-icons";

const Product = (props: any) => {
  const context = useContext(MyContext);
  if (!context) return null;
  const { favorites, setFavorites, compares, setCompares } = context;

  let product = null;
  if (props.favorite) {
    product = products.find((item) => item.id === props.favorite.productId);
  }
  if (props.compare) {
    product = products.find((item) => item.id === props.compare.productId);
  }
  if (props.product) {
    product = products.find((item) => item.id === props.product.id);
  }

  const [existFavorite, setExistFavorite] = useState(false);
  const [existCompare, setExistCompare] = useState(false);

  // handle favorite click
  const handleFavorite = () => {
    // create favorite item
    const favoriteItem = {
      id: String(favorites.length + 1),
      productId: product?.id,
    };

    // get favorite existed
    const favoriteExisted = favorites?.find(
      (item: any) => item.productId === product?.id
    );

    // check favorite existed
    if (!favoriteExisted) {
      setFavorites([...favorites, favoriteItem]);
      setExistFavorite(true);
    } else {
      const updatedFavorites = favorites.filter(
        (item: any) => item.productId !== product?.id
      );
      setFavorites(updatedFavorites);
      setExistFavorite(false);
    }
  };

  // handle compare click
  const handleCompare = () => {
    // create compare item
    const compareItem = {
      id: String(compares.length + 1),
      productId: product?.id,
    };

    // get compare existed
    const compareExisted = compares?.find(
      (item: any) => item.productId === product?.id
    );

    // check compare existed
    if (!compareExisted) {
      setCompares([...compares, compareItem]);
      setExistCompare(true);
    } else {
      const updatedCompares = compares.filter(
        (item: any) => item.productId !== product?.id
      );
      setCompares(updatedCompares);
      setExistCompare(false);
    }
  };

  useEffect(() => {
    // read favorite status
    const favoriteExisted = favorites?.find(
      (item: any) => item.productId === product?.id
    );
    if (!favoriteExisted) {
      setExistFavorite(false);
    } else {
      setExistFavorite(true);
    }

    // read compare status
    const compareExisted = compares?.find(
      (item: any) => item.productId === product?.id
    );
    if (!compareExisted) {
      setExistCompare(false);
    } else {
      setExistCompare(true);
    }
  }, []);

  return (
    <div className="w-[9rem] md:w-[16rem]  border rounded-2xl overflow-hidden mt-3">
      <Link to={"/product/" + product?.id}>
        <div className="overflow-hidden">
          <img
            src={product?.imgUrl}
            alt=""
            className="transition-all duration-500 hover:scale-105"
          />
        </div>
      </Link>
      <div className="flex flex-col px-2 mt-1">
        <span className="mb-2 text-sm text-gray-500">{product?.category}</span>
        <Link to={"/product/" + product?.id}>{product?.title}</Link>
        <span>${product?.price}</span>
        <div className="flex items-center flex-wrap gap-2 my-2">
          <button
            className={`cursor-pointer ${
              existFavorite
                ? "rounded-full border px-3 py-1 text-xs bg-red-50 text-red-600 border-red-200"
                : "rounded-full border px-2 py-1 text-xs"
            }`}
            onClick={() => handleFavorite()}
          >
            <FontAwesomeIcon icon={faHeart} />
            Favorite
          </button>
          <button
            className={`cursor-pointer ${
              existCompare
                ? "rounded-full border px-3 py-1 text-xs bg-red-50 text-red-600 border-red-200"
                : "rounded-full border px-2 py-1 text-xs"
            }`}
            onClick={() => handleCompare()}
          >
            <FontAwesomeIcon icon={faCodeCompare} />
            Compare
          </button>
        </div>
      </div>
    </div>
  );
};

export default Product;
