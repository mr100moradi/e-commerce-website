// import "bootstrap/dist/css/bootstrap.min.css";
// import "bootstrap/dist/js/bootstrap.bundle.min.js";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./SlideShow.css";
import Slide from "../slide/Slide";
import slider1 from "../../assets/images/banners/banner-1.jpg";
import slider2 from "../../assets/images/banners/banner-2.jpg";
import slider3 from "../../assets/images/banners/banner-3.jpg";

const SlideShow = () => {
  const slides = [
    {
      id:1,
      imgUrl: slider1,
    },
    {
      id:2,
      imgUrl: slider2,
    },
    {
      id:3,
      imgUrl: slider3,
    },
  ];

  // Custom Prev Button
  const PrevArrow = ({ className, onClick }: any) => (
    <button
      type="button"
      className={`${className}`}
      onClick={onClick}
      style={{ zIndex: 1 }}
    >
      ‹
    </button>
  );

  // Custom Next Button
  const NextArrow = ({ className, onClick }: any) => (
    <button
      type="button"
      className={`${className}`}
      onClick={onClick}
      style={{ zIndex: 1 }}
    >
      ›
    </button>
  );

  const settings = {
    centerMode: true,
    centerPadding: "0px", // how much of next/prev slide to show
    slidesToShow: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    infinite: true,
    speed: 500,
    prevArrow: <PrevArrow />,
    nextArrow: <NextArrow />,
    dots: true,
  };

  return (
    <Slider {...settings} className="mt-16">
      {slides.map((slide: any) => (
        <Slide key={slide.id} imgUrl={slide.imgUrl} />
      ))}
    </Slider>
  );
};

export default SlideShow;
