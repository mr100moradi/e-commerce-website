import { useContext, useEffect, useState } from "react";
import Footer from "../../components/footer/Footer";
import Header from "../../components/header/Header";
import MobileMenu from "../../components/header/MobileMenu";
import "./Product.css";
import { Link, useParams } from "react-router-dom";
import { products } from "../../data/products";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCodeCompare, faHeart } from "@fortawesome/free-solid-svg-icons";
import RelatedProducts from "../../components/related-prooduct/RelatedProducts";
import { type cartItem } from "../../data/cartItems";
import { MyContext } from "../MyContext";

const Product = () => {
  // read context
  const context = useContext(MyContext);
  if (!context) return null;
  const {
    cartItems,
    setCartItems,
    favorites,
    setFavorites,
    compares,
    setCompares,
  } = context;

  const { id } = useParams();

  const [count, setCount] = useState(1);
  const [menu, setMenu] = useState(false);
  const [existFavorite, setExistFavorite] = useState(false);
  const [existCompare, setExistCompare] = useState(false);

  // find product
  const productFinded = products.find((product) => product.id === id);

  // Sync count with cart item if product exists in cart
  useEffect(() => {
    const existingCartItem = cartItems?.find(
      (item: any) => item.productObject.id === productFinded?.id
    );
    if (existingCartItem) {
      setCount(existingCartItem.number);
    }
  }, [cartItems, productFinded?.id]);

  // add to cart function
  const addToCart = () => {
    const cartItemId = cartItems?.length || 0;

    // new cart item
    const cartItem: cartItem = {
      id: String(cartItemId + 1),
      productId: String(id),
      productObject: productFinded as object,
      amazingSaleId: null,
      amazingSaleObject: null,
      number: count,
    };

    // existed cart item
    const cartItemExisted = cartItems?.find(
      (cartItem: any) => cartItem.productObject.id === productFinded?.id
    );

    // check existed cart item
    if (!cartItemExisted) {
      // add new cart item
      setCartItems([...cartItems, cartItem]);
    } else {
      const updatedCartItems = cartItems?.map((cartItem: any) => {
        if (cartItem.productObject.id === productFinded?.id) {
          return { ...cartItem, number: count };
        }
        return cartItem; // Return the original item if it's not the one we're updating
      });
      // update cart items
      setCartItems(updatedCartItems);
    }
  };

  // handle favorite click
  const handleFavorite = () => {
    // create favorite item
    const favoriteItem = {
      id: String(favorites.length + 1),
      productId: id,
    };

    // get favorite existed
    const favoriteExisted = favorites?.find(
      (item: any) => item.productId === id
    );

    // check favorite existed
    if (!favoriteExisted) {
      setFavorites([...favorites, favoriteItem]);
      setExistFavorite(false);
    } else {
      const updatedFavorites = favorites.filter(
        (item: any) => item.productId !== id
      );
      setFavorites(updatedFavorites);
      setExistFavorite(true);
    }
  };

  // handle compare click
  const handleCompare = () => {
    // create compare item
    const compareItem = {
      id: String(compares.length + 1),
      productId: id,
    };

    // get compare existed
    const compareExisted = compares?.find((item: any) => item.productId === id);

    // check compare existed
    if (!compareExisted) {
      setCompares([...compares, compareItem]);
      setExistCompare(false);
    } else {
      const updatedCompares = compares.filter(
        (item: any) => item.productId !== id
      );
      setCompares(updatedCompares);
      setExistCompare(true);
    }
  };

  useEffect(() => {
    // read favorite status
    const favoriteExisted = favorites?.find(
      (item: any) => item.productId === id
    );
    if (!favoriteExisted) {
      setExistFavorite(false);
    } else {
      setExistFavorite(true);
    }

    // read compare status
    const compareExisted = compares?.find((item: any) => item.productId === id);
    if (!compareExisted) {
      setExistCompare(false);
    } else {
      setExistCompare(true);
    }
  }, []);

  return (
    <div className="relative">
      {menu && (
        <div
          className="bg-black/30 absolute top-0 left-0 right-0 bottom-0 z-3"
          onClick={() => setMenu(false)}
        ></div>
      )}
      <MobileMenu menu={menu} />
      <Header menu={menu} setMenu={setMenu} />
      <main className="px-4 md:px-48 py-4">
        <div className="grid grid-cols-2 gap-6 mt-20">
          <div className="border rounded-2xl overflow-hidden">
            <img src={productFinded?.imgUrl} alt="" className="w-5xl h-5xl" />
          </div>
          <div className="flex flex-col border rounded-2xl overflow-hidden p-5">
            <span className="text-slate-500">{productFinded?.category}</span>
            <span className="mt-5 text-2xl font-semibold">
              {productFinded?.title}
            </span>
            <span className="text-xl mt-5">${productFinded?.price}</span>
            <span className="text-slate-700 mt-5">
              {productFinded?.description}
            </span>
            <div className="flex items-center gap-3 mt-5">
              <div className="inline-flex items-center rounded-full border">
                <button
                  className="cursor-pointer h-9 w-9 text-lg"
                  aria-label="Decrease quantity"
                  onClick={() => {
                    count > 1 && setCount(count - 1);
                  }}
                >
                  −
                </button>
                <input
                  min="1"
                  className="h-9 w-12 border-l border-r text-center text-sm focus:outline-none"
                  type="number"
                  value={count}
                  readOnly={true}
                />
                <button
                  className="cursor-pointer h-9 w-9 text-lg"
                  aria-label="Increase quantity"
                  onClick={() => {
                    count < 10 && setCount(count + 1);
                  }}
                >
                  +
                </button>
              </div>
              <button
                className="cursor-pointer rounded-xl bg-black text-white text-sm px-4 py-2"
                onClick={() => addToCart()}
              >
                Add to cart
              </button>
              <div className="flex items-center gap-2 my-2">
                <button
                  className={`cursor-pointer ${
                    existFavorite
                      ? "rounded-full border px-3 py-1 text-xs bg-red-50 text-red-600 border-red-200"
                      : "rounded-full border px-2 py-1 text-xs"
                  }`}
                  onClick={() => handleFavorite()}
                >
                  <FontAwesomeIcon icon={faHeart} />
                  Favorite
                </button>
                <button
                  className={`cursor-pointer ${
                    existCompare
                      ? "rounded-full border px-3 py-1 text-xs bg-red-50 text-red-600 border-red-200"
                      : "rounded-full border px-2 py-1 text-xs"
                  }`}
                  onClick={() => handleCompare()}
                >
                  <FontAwesomeIcon icon={faCodeCompare} />
                  Compare
                </button>
              </div>
            </div>
            <div className="mt-4">
              <Link
                to="/shop"
                className="w-full text-sm border rounded-lg px-3 py-2 mt-3"
              >
                Back to shop
              </Link>
            </div>
            <span className="text-slate-500 text-xs mt-5">
              In stock: {productFinded?.stock}
            </span>
          </div>
        </div>
        <RelatedProducts productFinded={productFinded} />
      </main>
      <Footer />
    </div>
  );
};

export default Product;
