import { Link } from "react-router-dom";
import "./TrendingNow.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { products } from "../../data/products";
import Product from "../product/Product";

const TrendingNow = () => {


  // Custom Prev Button
  const PrevArrow = ({ className, onClick }: any) => (
    <button
      type="button"
      className={`${className}`}
      onClick={onClick}
      style={{ zIndex: 1 }}
    >
      ‹
    </button>
  );

  // Custom Next Button
  const NextArrow = ({ className, onClick }: any) => (
    <button
      type="button"
      className={`${className}`}
      onClick={onClick}
      style={{ zIndex: 1 }}
    >
      ›
    </button>
  );

  const settings = {
    centerMode: true,
    centerPadding: "0px",
    slidesToShow: 4,
    slidesToScroll: 4,
    initialSlide: 0,
    autoplay: true,
    autoplaySpeed: 3000,
    infinite: true,
    speed: 500,
    prevArrow: <PrevArrow />,
    nextArrow: <NextArrow />,
    dots: false,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  return (
    <>
      <div className="flex justify-between items-center mt-10">
        <span className="capitalize font-semibold text-lg">Trending now</span>
        <Link to="/shop">Browse all</Link>
      </div>
      <div className=" mt-5">
        <Slider {...settings}>
          {products.map((item: any) => (
            <Product key={item.id} product={item} />
          ))}
        </Slider>
      </div>
    </>
  );
};

export default TrendingNow;
