import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <div className="px-4 md:px-48 py-4 border-t">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-3 my-3 text-center">
        <div className="text-gray-500 text-xs">
          © 2025 Arico Shop
        </div>
        <div className="flex justify-center items-center gap-5">
          <Link
            to="/"
            className="text-gray-500 text-sm transition-all hover:text-black"
          >
            Privacy
          </Link>
          <Link
            to="/"
            className="text-gray-500 text-sm transition-all hover:text-black"
          >
            Terms
          </Link>
          <Link
            to="/"
            className="text-gray-500 text-sm transition-all hover:text-black"
          >
            Support
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Footer;
