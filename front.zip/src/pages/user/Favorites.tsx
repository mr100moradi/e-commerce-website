import { useContext } from "react";
import "./Favorites.css";
import { MyContext } from "../MyContext";
import Product from "../../components/product/Product";

const Favorites = () => {
  const context = useContext(MyContext);
  if (!context) return null;
  const { favorites } = context;

  return (
    <>
      <h2 className="capitalize font-semibold text-3xl">Profile</h2>
      <div className="border rounded-xl p-5 mt-5">
        <h2 className="capitalize font-semibold text-xl">Favorites</h2>
        <div className="flex items-center flex-wrap gap-3">
          {favorites?.map((item: any) => (
            <Product key={item.id} favorite={item} />
          ))}
        </div>
      </div>
    </>
  );
};

export default Favorites;
