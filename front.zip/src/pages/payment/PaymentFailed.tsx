import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes, faHome, faRedo } from "@fortawesome/free-solid-svg-icons";

const PaymentFailed = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [isLoading, setIsLoading] = useState(true);
  const [errorDetails, setErrorDetails] = useState<any>(null);

  useEffect(() => {
    // Simulate loading time for better UX
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    // Get error details from URL parameters
    const errorCode = searchParams.get("errorCode") || searchParams.get("code");
    const errorMessage =
      searchParams.get("errorMessage") || searchParams.get("error");
    const authority = searchParams.get("Authority");

    setErrorDetails({
      errorCode: errorCode || "Unknown",
      errorMessage: errorMessage || "Payment failed",
      authority: authority || "Unknown",
      date: new Date().toLocaleDateString("en-US"),
      time: new Date().toLocaleTimeString("en-US"),
    });

    return () => clearTimeout(timer);
  }, [searchParams]);


  if (isLoading) {
    return (
      <div className="flex justify-center items-center w-dvw h-dvh">
        <div className="flex items-center gap-5 w-xs p-5 bg-indigo-500 text-white rounded-2xl ">
          <div className="size-7 animate-spin rounded-full border-4 border-slate-400 border-r-amber-500"></div>
          <div>
            <h2>Checking payment status...</h2>
            <p>Please wait</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-400 to-red-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 to-red-600"></div>

        <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-6 text-white text-3xl animate-pulse">
          <FontAwesomeIcon icon={faTimes} />
        </div>

        <h1 className="text-2xl font-bold text-red-600 mb-4">Payment Failed</h1>
        <p className="text-gray-600 mb-6">
          Unfortunately, your payment was not successful. Please try again or
          contact support.
        </p>

        <div className="bg-red-50 rounded-xl p-4 mb-6 text-left border border-red-200">
          <p className="text-sm text-gray-600 mb-2">
            <span className="font-semibold">Error Code:</span>
            <span className="text-red-600 font-mono ml-2">
              {errorDetails?.errorCode}
            </span>
          </p>
          <p className="text-sm text-gray-600 mb-2">
            <span className="font-semibold">Error Message:</span>
            <span className="text-red-600 ml-2">
              {errorDetails?.errorMessage}
            </span>
          </p>
          <p className="text-sm text-gray-600">
            <span className="font-semibold">Date:</span>
            <span className="ml-2">
              {errorDetails?.date} - {errorDetails?.time}
            </span>
          </p>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => navigate("/checkout")}
            className="block w-full bg-gradient-to-r from-red-500 to-red-600 text-white py-3 px-6 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200"
          >
            <FontAwesomeIcon icon={faRedo} className="mr-2" />
            Try Again
          </button>
          <button
            onClick={() => navigate("/")}
            className="block w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-xl font-semibold hover:bg-gray-200 transition-all duration-200"
          >
            <FontAwesomeIcon icon={faHome} className="mr-2" />
            Back to Site
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentFailed;
