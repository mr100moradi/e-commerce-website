import { Link } from "react-router-dom";
import "./MobileMenu.css";
import { useContext } from "react";
import { MyContext } from "../../pages/MyContext";

const MobileMenu = (props: any) => {
  // read context
  const context = useContext(MyContext);
  if (!context) return null;
  const { cartItemsCount } = context;

  return (
    props.menu && (
      <div className="fixed top-[4.5rem] flex flex-col w-80 bg-white border mx-5 px-2 py-4 rounded-xl z-3">
        <Link
          to="/"
          className="cursor-pointer capitalize text-gray-600 transition-all hover:bg-slate-100 hover:text-black rounded-xl px-3 py-2"
        >
          home
        </Link>
        <Link
          to="/shop"
          className="cursor-pointer capitalize text-gray-600 transition-all hover:bg-slate-100 hover:text-black rounded-xl px-3 py-2"
        >
          shop
        </Link>
        <Link
          to="/cart"
          className="relative cursor-pointer capitalize text-gray-600 transition-all hover:bg-slate-100 hover:text-black rounded-xl px-3 py-2"
        >
          {cartItemsCount > 0 && (
            <span className="absolute top-1 left-10 bg-black text-white text-xs rounded-full px-[5px]">
              {cartItemsCount}
            </span>
          )}
          cart
        </Link>
        <Link
          to="/user-profile"
          className="cursor-pointer capitalize text-gray-600 transition-all hover:bg-slate-100 hover:text-black rounded-xl px-3 py-2"
        >
          profile
        </Link>
      </div>
    )
  );
};

export default MobileMenu;
