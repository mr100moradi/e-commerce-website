export type category = {
  id: number;
  title: string;
  imgUrl: string;
};

import category1 from "../assets/images/categories/category-1.jpg";
import category2 from "../assets/images/categories/category-2.jpg";
import category3 from "../assets/images/categories/category-3.jpg";
import category4 from "../assets/images/categories/category-4.jpg";
import category5 from "../assets/images/categories/category-5.jpg";
import category6 from "../assets/images/categories/category-6.jpg";

export const categories: category[] = [
  {
    id: 1,
    title: "Shoes",
    imgUrl: category1,
  },
  {
    id: 2,
    title: "Bags",
    imgUrl: category2,
  },
  {
    id: 3,
    title: "Accessories",
    imgUrl: category3,
  },
  {
    id: 4,
    title: "Clothing",
    imgUrl: category4,
  },
  {
    id: 5,
    title: "Electronics",
    imgUrl: category5,
  },
  {
    id: 6,
    title: "Home",
    imgUrl: category6,
  },
];
