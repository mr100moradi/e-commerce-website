import { useContext, useEffect, useState } from "react";
import "./Cart.css";
import { MyContext } from "../MyContext";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faLock,
  faShieldHalved,
  faShippingFast,
  faTicket,
} from "@fortawesome/free-solid-svg-icons";
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import MobileMenu from "../../components/header/MobileMenu";
import CartItem from "./CartItem";
import { Link, useNavigate } from "react-router-dom";

const Cart = () => {
  // read context
  const context = useContext(MyContext);
  if (!context) return null;
  const { setCartItemsCount, cartItems, setCartItems } = context;

  const navigate = useNavigate();

  const [menu, setMenu] = useState(false);
  const [subtotal, setSubtotal] = useState(0);
  const [shipping, setShipping] = useState(9);
  const [total, setTotal] = useState(0);

  const clearCart = () => {
    setCartItemsCount(0);
  };

  useEffect(() => {
    let total = 0;
    cartItems?.forEach((cartItem) => {
      const product = cartItem.productObject;
      const price = parseInt(product.price);
      const finalPrice = price * cartItem.number;
      total = total + finalPrice;
    });
    setSubtotal(total);
    setTotal(total + shipping);
  }, []);

  return (
    <div className="relative">
      {menu && (
        <div
          className="bg-black/30 absolute top-0 left-0 right-0 bottom-0 z-3"
          onClick={() => setMenu(false)}
        ></div>
      )}
      <MobileMenu menu={menu} />
      <Header menu={menu} setMenu={setMenu} />
      <main className="px-4 md:px-48 py-4">
        <div className="flex justify-between items-center mt-20">
          <h2 className="capitalize font-semibold text-3xl">Your Cart</h2>
          <button className="" onClick={() => clearCart()}>
            Clear all
          </button>
        </div>
        <div className="flex flex-col border rounded-2xl p-5 mt-4">
          <div className="flex items-center gap-2">
            <FontAwesomeIcon icon={faShippingFast} />
            <span className="text-slate-700">
              Add $66.01 more to get free shipping
            </span>
          </div>
          <span className="relative bg-slate-100 w-full h-2 mt-2 rounded-full">
            <span className="absolute top-0 left-0 bottom-0 bg-black w-36 md:w-90 h-2 rounded-full"></span>
          </span>
        </div>
        <div className="grid grid-cols-12 gap-5">
          <div className="col-span-12 md:col-span-8 border rounded-2xl p-5 mt-4">
            {cartItems?.map((cartItem: any) => (
              <CartItem
                key={cartItem.id}
                cartItem={cartItem}
                subtotal={subtotal}
                setSubtotal={setSubtotal}
                total={total}
                setTotal={setTotal}
              />
            ))}
          </div>
          <div className="col-span-12 md:col-span-4 border rounded-2xl p-5 mt-4">
            <span className="capitalize text-lg font-semibold">
              Order Summary
            </span>
            <div className="flex justify-between items-center mt-3">
              <span className="text-sm text-slate-600">Subtotal</span>
              <span className="text-sm text-slate-600">${subtotal}</span>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm text-slate-600">Discount</span>
              <span className="text-sm text-slate-600">${0}</span>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm text-slate-600">Shipping</span>
              <span className="text-sm text-slate-600">${shipping}</span>
            </div>
            <hr className="text-slate-200 my-3" />
            <div className="flex justify-between items-center">
              <span className="text-md font-semibold">Total</span>
              <span className="text-md font-semibold">${total}</span>
            </div>
            <div className="mt-3">
              <span className="text-sm text-slate-600">Promo code</span>
              <div className="flex items-center gap-2 mt-2">
                <div className="relative flex-1">
                  <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                    <FontAwesomeIcon icon={faTicket} />
                  </span>
                  <input
                    placeholder="e.g. WELCOME10"
                    className="w-full rounded-xl border bg-white pl-9 pr-3 py-2 text-sm"
                    value=""
                  />
                </div>
                <button className="cursor-pointer bg-black text-white rounded-xl px-4 py-2">
                  Apply
                </button>
              </div>
            </div>
            <button
              className="cursor-pointer w-full bg-black text-white rounded-xl px-4 py-3 mt-3"
              onClick={() => navigate("/checkout")}
            >
              Proceed to Checkout
            </button>
            <div className="text-center mt-3">
              <Link
                to="/shop"
                className="text-slate-600 text-sm hover:text-black"
              >
                Continue shopping
              </Link>
            </div>
            <div className="flex justify-center items-center gap-3">
              <div className="flex flex-col justify-center items-center border rounded-2xl text-center text-[11px] w-full p-3 mt-2">
                <FontAwesomeIcon icon={faShieldHalved} />
                <span className="text-slate-600">Secure</span>
                <span className="text-slate-600">payments</span>
              </div>
              <div className="flex flex-col justify-center items-center border rounded-2xl text-center text-[11px] w-full p-3 mt-2">
                <FontAwesomeIcon icon={faShippingFast} />
                <span className="text-slate-600">Secure</span>
                <span className="text-slate-600">payments</span>
              </div>
              <div className="flex flex-col justify-center items-center border rounded-2xl text-center text-[11px] w-full p-3 mt-2">
                <FontAwesomeIcon icon={faLock} />
                <span className="text-slate-600">Secure</span>
                <span className="text-slate-600">payments</span>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Cart;
