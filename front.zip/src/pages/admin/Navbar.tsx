import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./Navbar.css";
import {
  faAngleLeft,
  faAngleRight,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import { useState } from "react";
import SidebarItem from "./SidebarItem";

const Navbar = (props:any) => {
  

  return (
    <div
      className={`col-span-12 ${
        props.sidebarCollapsed ? "xl:col-span-1" : "xl:col-span-2"
      } border border-gray-200 rounded-2xl p-5`}
    >
      <nav>
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <FontAwesomeIcon icon={faUser} className="text-amber-600 text-xl" />
            <span className={`ml-2 ${props.sidebarCollapsed ? "hidden" : "block"}`}>
              Admin
            </span>
          </div>
          <FontAwesomeIcon
            icon={props.sidebarCollapsed ? faAngleRight : faAngleLeft}
            className="text-gray-500"
            onClick={() => props.setSidebarCollapsed(!props.sidebarCollapsed)}
          />
        </div>
        <SidebarItem
          title="Jobs"
          sidebarCollapsed={props.sidebarCollapsed}
        />
        <SidebarItem
          title="Projects"
          sidebarCollapsed={props.sidebarCollapsed}
        />
      </nav>
    </div>
  );
};

export default Navbar;
