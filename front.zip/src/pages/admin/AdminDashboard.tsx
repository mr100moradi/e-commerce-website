import { useContext, useEffect, useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Footer from "../../components/footer/Footer";
import Header from "../../components/header/Header";
import "./AdminDashboard.css";
import Navbar from "./Navbar";
import { faUser } from "@fortawesome/free-solid-svg-icons";
import IndexProject from "./IndexProject";
import IndexJob from "./IndexJob";
import { MyContext } from "./MyContext";
import Cookies from "universal-cookie";
import axios from "axios";
import Api from "../../utils/Api";

const AdminDashboard = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { activeTab, setUser } = context;
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const cookies = new Cookies();
  const token = cookies.get("TOKEN");

  // const getUser = () => {
  //   const config = {
  //     method: "GET",
  //     url: `${Api}/user/getUser`,
  //     headers: {
  //       Authorization: `Bearer ${token}`,
  //     },
  //   };
  //   axios(config)
  //     .then((result) => {
  //       setUser(result.data);
  //     })
  //     .catch((error) => console.log(error));
  // };

  // useEffect(() => {
  //   getUser();
  // }, []);

  return (
    <>
      <Header />
      <div className="px-4 md:px-36 my-10">
        <div className="grid grid-rows-1 grid-cols-12 gap-5">
          <Navbar
            sidebarCollapsed={sidebarCollapsed}
            setSidebarCollapsed={setSidebarCollapsed}
          />

          <div
            className={`col-span-12 ${
              sidebarCollapsed ? "xl:col-span-11" : "xl:col-span-10"
            }`}
          >
            <div className="grid grid-cols-12 border border-gray-200 rounded-2xl p-5 space-y-6 md:space-y-0">
              <div className="col-span-12 sm:col-span-6 flex flex-col">
                <span className="capitalize font-bold text-xl">
                  Employer Dashboard
                </span>
                <span className="text-gray-600 text-sm">
                  Create and manage jobs and projects
                </span>
              </div>

              <div className="col-span-12 sm:col-span-6 flex justify-start sm:justify-end items-center gap-2">
                <div className="flex flex-col">
                  <span>M.Reza Moradi</span>
                  <span className="text-gray-600 text-sm">
                    mr99.moradi@gmail.com
                  </span>
                </div>
                <span className="flex justify-center items-center ">
                  <FontAwesomeIcon
                    icon={faUser}
                    className="bg-amber-600 rounded-full px-2.5 py-3"
                  />
                </span>
              </div>
            </div>

            {activeTab === "Jobs" && <IndexJob />}
            {activeTab === "Projects" && <IndexProject />}
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default AdminDashboard;
