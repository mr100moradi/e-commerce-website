export type favorite = {
  id: string;
  productId: string;
};


// Shoes, Bags, Accessories, Clothing, Electronics, Home

export const favorites: favorite[] = [

];


// export const loadCartFromStorage = (): cartItem[] => {
//   try {
//     const raw = localStorage.getItem('cart');
//     return raw ? (JSON.parse(raw) as cartItem[]) : [];
//   } catch {
//     return [];
//   }
// };

// export const saveCartToStorage = (cart: cartItem[]) => {
//   try {
//     localStorage.setItem('cart', JSON.stringify(cart));
//   } catch {
//     // به‌عنوان fallback: ignore
//   }
// };