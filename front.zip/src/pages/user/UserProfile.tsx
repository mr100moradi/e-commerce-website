import { useState } from "react";
import Header from "../../components/header/Header";
import TabItem from "./TabItem";
import Footer from "../../components/footer/Footer";
import Account from "./Account";
import Favorites from "./Favorites";
import Compares from "./Compares";
import MobileMenu from "../../components/header/MobileMenu";

const UserProfile = () => {
  const [activeTab, setActiveTab] = useState<
    "account" | "favorites" | "compares"
  >("account");

  const [menu, setMenu] = useState(false);
  return (
    <div className="relative">
      {menu && (
        <div
          className="bg-black/30 absolute top-0 left-0 right-0 bottom-0 z-3"
          onClick={() => setMenu(false)}
        ></div>
      )}
      <MobileMenu menu={menu} />
      <Header menu={menu} setMenu={setMenu} />
      <main className="px-4 md:px-44 py-4">
        <div className="grid grid-cols-12 gap-2 rounded-2xl bg-white space-y-6 mt-20">
          <div className="col-span-12 md:col-span-2 gap-2 border rounded-xl p-2">
            <TabItem
              title="account"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />
            <TabItem
              title="favorites"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />
            <TabItem
              title="compares"
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />
          </div>
          <div className="col-span-12 md:col-span-10 p-1">
            {activeTab === "account" && <Account />}
            {activeTab === "favorites" && <Favorites />}
            {activeTab === "compares" && <Compares />}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default UserProfile;
