import { Link } from "react-router-dom";

const Category = (props: any) => {
  return (
    <Link
      to={"/shop/"+false+"/" + props.category.title}
      className="relative col-span-2 rounded-xl overflow-hidden border w-44 h-32"
    >
      <img
        src={props.category.imgUrl}
        alt=""
        className="absolute transition-all duration-500 hover:scale-105"
      />
      <span className="absolute top-24 left-2 text-white">
        {props.category.title}
      </span>
    </Link>
  );
};

export default Category;
