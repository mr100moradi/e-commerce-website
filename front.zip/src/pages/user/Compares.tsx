import { useContext } from "react";
import "./Compares.css";
import { MyContext } from "../MyContext";
import Product from "../../components/product/Product";

const Compares = () => {
  const context = useContext(MyContext);
  if (!context) return null;
  const { compares } = context;

  return (
    <>
      <h2 className="capitalize font-semibold text-3xl">Profile</h2>
      <div className="border rounded-xl p-5 mt-5">
        <h2 className="capitalize font-semibold text-xl">Compares</h2>
        <div className="flex items-center flex-wrap gap-3">
          {compares?.map((item: any) => (
            <Product key={item.id} compare={item} />
          ))}
        </div>
      </div>
    </>
  );
};

export default Compares;
