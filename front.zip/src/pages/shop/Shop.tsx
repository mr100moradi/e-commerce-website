import { useEffect, useState } from "react";
import Footer from "../../components/footer/Footer";
import Header from "../../components/header/Header";
import "./Shop.css";
import MobileMenu from "../../components/header/MobileMenu";
import Product from "../../components/product/Product";
import { products } from "../../data/products";
import { useParams } from "react-router-dom";

const Shop = () => {
  const { searchText, categoryText } = useParams();

  const [menu, setMenu] = useState(false);
  const [search, setSearch] = useState(
    searchText === "false" ? "" : searchText
  );
  const [category, setCategory] = useState(
    categoryText === "false" ? "All" : categoryText
  );
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [sort, setSort] = useState("newest");
  const [perPage, setPerPage] = useState(8);
  const [currentPage, setCurrentPage] = useState(1);

  // filter products
  let filteredProducts = products.filter((product: any) => {
    const searchLower = search?.toLowerCase();

    let matchesSearch = true;

    if (category) {
      matchesSearch =
        matchesSearch && (category === "All" || product.category === category);
    }
    if (search) {
      matchesSearch =
        matchesSearch && product.title.toLowerCase().includes(searchLower);
    }
    if (minPrice) {
      matchesSearch =
        matchesSearch && parseInt(product.price) >= parseInt(minPrice);
    }
    if (maxPrice) {
      matchesSearch =
        matchesSearch && parseInt(product.price) <= parseInt(maxPrice);
    }
    return matchesSearch;
  });

  // sort products
  filteredProducts.sort((a: any, b: any) => {
    switch (sort) {
      case "newest":
      case "price_asc":
        return parseInt(a.price) - parseInt(b.price);
      case "price_desc":
        return parseInt(b.price) - parseInt(a.price);
      case "title_asc":
        return a.title - b.title;
      default:
        return parseInt(a.id) - parseInt(b.id);
    }
  });

  // pagination calculate
  const totalPages = Math.ceil(filteredProducts.length / perPage);
  const filteredProductsPaginated = filteredProducts.slice(
    (currentPage - 1) * perPage,
    currentPage * perPage
  );

  return (
    <div className="relative">
      {menu && (
        <div
          className="bg-black/30 absolute top-0 left-0 right-0 bottom-0 z-3"
          onClick={() => setMenu(false)}
        ></div>
      )}
      <MobileMenu menu={menu} />
      <Header menu={menu} setMenu={setMenu} />
      <main className="px-4 md:px-48 py-4">
        <div className="flex justify-between items-center mt-16">
          <span className="capitalize font-semibold text-lg">Shop</span>
          <span>{filteredProducts.length} results</span>
        </div>
        <div className="flex justify-between items-center flex-wrap">
          <div className="relative w-full sm:max-w-md mt-5">
            <input
              placeholder="Search products..."
              className="w-full rounded-xl border bg-white px-4 py-2.5 pr-10 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-gray-900/10"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
              🔎
            </span>
          </div>
          <div className="flex justify-start md:justify-end items-center flex-wrap gap-2 mt-5">
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Min price"
                className="w-28 rounded-xl border bg-white px-3 py-2 text-sm shadow-sm"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
              />
              <span className="text-gray-400">—</span>
              <input
                type="text"
                placeholder="Max price"
                className="w-28 rounded-xl border bg-white px-3 py-2 text-sm shadow-sm"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
              />
            </div>
            <select
              name=""
              id=""
              className="rounded-xl border bg-white px-3 py-2 text-sm shadow-sm"
              value={sort}
              onChange={(e) => setSort(e.target.value)}
            >
              <option value="newest">Newest</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="title_asc">Title: A → Z</option>
            </select>
            <select
              name=""
              id=""
              className="rounded-xl border bg-white px-3 py-2 text-sm shadow-sm"
              value={perPage}
              onChange={(e) => setPerPage(parseInt(e.target.value))}
            >
              <option value="8">8 / page</option>
              <option value="12">12 / page</option>
              <option value="16">16 / page</option>
              <option value="24">24 / page</option>
              <option value="32">32 / page</option>
            </select>
            <button
              className="rounded-xl border bg-white px-3 py-2 text-sm shadow-sm"
              onClick={() => {
                setCategory("");
                setSearch("");
                setMinPrice("");
                setMaxPrice("");
                setSort("newest");
                setPerPage(8);
              }}
            >
              Clear
            </button>
          </div>
        </div>
        <div className="flex justify-start items-center flex-wrap gap-2 mt-5">
          <button
            className={`cursor-pointer capitalize rounded-full transition-all ${
              category === "All" ? "bg-black text-white" : "border bg-white"
            } px-3 py-2 text-sm`}
            onClick={() => setCategory("All")}
          >
            All
          </button>
          <button
            className={`cursor-pointer capitalize rounded-full transition-all ${
              category === "Shoes" ? "bg-black text-white" : "border bg-white"
            } px-3 py-2 text-sm`}
            onClick={() => setCategory("Shoes")}
          >
            Shoes
          </button>
          <button
            className={`cursor-pointer capitalize rounded-full transition-all ${
              category === "Bags" ? "bg-black text-white" : "border bg-white"
            } px-3 py-2 text-sm`}
            onClick={() => setCategory("Bags")}
          >
            Bags
          </button>
          <button
            className={`cursor-pointer capitalize rounded-full transition-all ${
              category === "Accessories"
                ? "bg-black text-white"
                : "border bg-white"
            } px-3 py-2 text-sm`}
            onClick={() => setCategory("Accessories")}
          >
            Accessories
          </button>
          <button
            className={`cursor-pointer capitalize rounded-full transition-all ${
              category === "Clothing"
                ? "bg-black text-white"
                : "border bg-white"
            } px-3 py-2 text-sm`}
            onClick={() => setCategory("Clothing")}
          >
            Clothing
          </button>
          <button
            className={`cursor-pointer capitalize rounded-full transition-all ${
              category === "Electronics"
                ? "bg-black text-white"
                : "border bg-white"
            } px-3 py-2 text-sm`}
            onClick={() => setCategory("Electronics")}
          >
            Electronics
          </button>
          <button
            className={`cursor-pointer capitalize rounded-full transition-all ${
              category === "Home" ? "bg-black text-white" : "border bg-white"
            } px-3 py-2 text-sm`}
            onClick={() => setCategory("Home")}
          >
            Home
          </button>
        </div>

        {/* read product paginated */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5 mt-5">
          {filteredProductsPaginated?.map((item: any) => (
            <Product key={item.id} product={item} />
          ))}
        </div>

        {/* paginate */}
        <div className="text-center mt-8">
          <button
            disabled={currentPage === 1}
            onClick={() => setCurrentPage((prev) => prev - 1)}
            className="cursor-pointer rounded-xl px-4 py-2 mr-3 text-sm font-medium transition-all border text-black disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>

          {[...Array(totalPages)].map((x: any, i: any) =>
            i + 1 === currentPage ? (
              <button
                className="cursor-pointer rounded-xl px-4 py-2 mx-1 text-sm font-medium transition-all bg-black text-white"
                onClick={() => setCurrentPage(i + 1)}
              >
                {i + 1}
              </button>
            ) : (
              <button
                className="cursor-pointer rounded-xl px-4 py-2 mx-1 text-sm font-medium transition-all border text-black"
                onClick={() => setCurrentPage(i + 1)}
              >
                {i + 1}
              </button>
            )
          )}

          <button
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage((prev) => prev + 1)}
            className="cursor-pointer rounded-xl border-slate-200 bg-white px-4 py-2 ml-3 transition-all border text-black text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Shop;
