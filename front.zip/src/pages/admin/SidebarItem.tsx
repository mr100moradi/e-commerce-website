import { faUser } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./SidebarItem.css";
import { useContext } from "react";
import { MyContext } from "./MyContext";

const SidebarItem = (props: any) => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { activeTab, setActiveTab } = context;

  return (
    <button
      className={`cursor-pointer w-full flex items-center text-left ${
        activeTab === props.title
          ? "bg-amber-50 text-amber-700 border border-amber-200"
          : "hover:bg-gray-100"
      } rounded-lg p-1 mt-5`}
      onClick={() => setActiveTab(props.title)}
    >
      <FontAwesomeIcon icon={faUser} />
      <span className={`ml-2 ${props.sidebarCollapsed ? "hidden" : "block"}`}>
        {props.title}
      </span>
    </button>
  );
};

export default SidebarItem;
