import {
  faCartShopping,
  faSearch,
  faUser,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link, useNavigate } from "react-router-dom";
import { useContext, useState } from "react";
import { MyContext } from "../../pages/MyContext";

const Menu = (props: any) => {
  // read context
  const context = useContext(MyContext);
  if (!context) return null;
  const { cartItemsCount } = context;

  const navigate = useNavigate();

  const [search, setSearch] = useState("");

  const handleKeyDown = (e: any) => {
    if (e.key === "Enter") {
      navigate("/shop/" + search + "/" + false);
    }
  };

  return (
    <div className="hidden md:flex justify-center items-center gap-5 ml-auto z-1">
      <Link
        to="/shop"
        className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
      >
        shop
      </Link>
      <Link
        to="/cart"
        className="relative cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
      >
        {cartItemsCount > 0 && (
          <span className="absolute -top-3 -right-3 bg-black text-white text-xs rounded-full px-[5px]">
            {cartItemsCount}
          </span>
        )}
        <FontAwesomeIcon icon={faCartShopping} />
      </Link>
      <Link
        to="/profile"
        className="cursor-pointer capitalize text-gray-600 transition-all hover:text-black"
      >
        <FontAwesomeIcon icon={faUser} />
      </Link>
      <div className="ml-auto sm:ml-0 flex items-center gap-2">
        <form className="relative hidden sm:block">
          <input
            placeholder="Search products..."
            className="rounded-md border pl-9 pr-10 py-2 text-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => handleKeyDown(e)}
          />
          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-500">
            <FontAwesomeIcon icon={faSearch} />
          </span>
          <button
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-600 text-xs"
          ></button>
        </form>
      </div>
    </div>
  );
};

export default Menu;
