export type cartItem = {
  id: string;
  productId: string;
  productObject: object;
  amazingSaleId: string | null;
  amazingSaleObject: object | null;
  number: number;
};

import img1 from "../assets/images/trading-now/1.jpg";
import img2 from "../assets/images/trading-now/2.jpg";
import img3 from "../assets/images/trading-now/3.jpg";
import img4 from "../assets/images/trading-now/4.jpg";
import img5 from "../assets/images/trading-now/5.jpg";
import img6 from "../assets/images/trading-now/6.jpg";
import img7 from "../assets/images/trading-now/7.jpg";
import img8 from "../assets/images/trading-now/8.jpg";
import img9 from "../assets/images/trading-now/9.jpg";
import img10 from "../assets/images/trading-now/10.jpg";

// categories =>  Shoes, Bags, Accessories, Clothing, Electronics, Home

export const cartItems: cartItem[] = [

];
