const mongoose = require("mongoose");

const ConnectDb = async () => {
  try {
    await mongoose.connect(`mongodb://0.0.0.0:27017/${process.env.DB_PORT}`);
    console.log("database connected successfully");
  } catch (error) {
    console.log(error);
  }
};

module.exports = ConnectDb;
