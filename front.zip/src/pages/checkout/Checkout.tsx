import { useContext, useEffect, useState } from "react";
import "./Checkout.css";
import MobileMenu from "../../components/header/MobileMenu";
import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer";
import { MyContext } from "../MyContext";
import axios from "axios";
import Api from "../../utils/Api";

const Checkout = () => {
  // read context
  const context = useContext(MyContext);
  if (!context) return null;
  const { cartItems } = context;

  const [name, setName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");

  const [menu, setMenu] = useState(false);
  const [subtotal, setSubtotal] = useState(0);
  const [shipping, setShipping] = useState(9);
  const [total, setTotal] = useState(0);

  const handlePay = async (e: any) => {
    e.preventDefault();

    const amount = 1000;

    try {
      const account = {
        name: name,
        lastName: lastName,
        email: email,
        address: address,
        city: city,
        postalCode: postalCode,
      };
      // set account info in local storage
      localStorage.setItem("account", JSON.stringify(account));

      const res = await axios.post(`${Api}/payment-route/create-transaction`, {
        amount,
      });
      
      // get payment url from reponse
      const { payment_url } = res.data;
      if (payment_url) {
        // go to zarinpal gateway
        window.location.href = payment_url; 
      } else {
        // مدیریت حالت خطا
        alert("Unable to start payment");
      }
    } catch (err) {
      console.error(err);
      alert("Error creating transaction");
    }
  };

  useEffect(() => {
    //  set details order
    let subtotal = 0;
    cartItems?.forEach((cartItem) => {
      const product = cartItem.productObject;
      const price = parseInt(product.price);
      const finalPrice = price * cartItem.number;
      subtotal = subtotal + finalPrice;
    });
    setSubtotal(subtotal);
    setTotal(subtotal + shipping);

    //  get account info
    let account = localStorage.getItem("account");
    account = JSON.parse(account as string);
    setName(account?.name);
    setLastName(account?.lastName);
    setEmail(account?.email);
    setAddress(account?.address);
    setCity(account?.city);
    setPostalCode(account?.postalCode);
  }, [cartItems]);

  return (
    <div className="relative">
      {menu && (
        <div
          className="bg-black/30 absolute top-0 left-0 right-0 bottom-0 z-3"
          onClick={() => setMenu(false)}
        ></div>
      )}
      <MobileMenu menu={menu} />
      <Header menu={menu} setMenu={setMenu} />
      <main className="px-4 md:px-48 py-4">
        <h2 className="capitalize font-semibold text-3xl mt-20">Checkout</h2>
        <div className="grid grid-cols-12 gap-5">
          <div className="col-span-12 md:col-span-8 ">
            <div className="flex flex-col gap-4 border rounded-2xl p-5 mt-4">
              <h2 className="capitalize text-lg font-semibold">
                Shipping information
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                <div>
                  <label className="mb-1 block text-sm text-gray-600">
                    First name
                  </label>
                  <input
                    type="text"
                    className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm text-gray-600">
                    Last name
                  </label>
                  <input
                    type="text"
                    className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-sm text-gray-600">
                    Email
                  </label>
                  <input
                    type="email"
                    className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-sm text-gray-600">
                    Address
                  </label>
                  <input
                    type="text"
                    className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm text-gray-600">
                    City
                  </label>
                  <input
                    type="text"
                    className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm text-gray-600">
                    Postal code
                  </label>
                  <input
                    type="text"
                    className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                    value={postalCode}
                    onChange={(e) => setPostalCode(e.target.value)}
                  />
                </div>
              </div>
            </div>
            <div className="border rounded-2xl p-5 mt-6">
              <h2 className="capitalize text-lg font-semibold">Payment</h2>
              <span className="block text-sm text-gray-600 my-2">
                Payment integration placeholder.
              </span>
            </div>
          </div>
          <div className="col-span-12 md:col-span-4 border rounded-2xl p-5 mt-4">
            <span className="capitalize text-lg font-semibold">
              Order Summary
            </span>
            <div className="flex justify-between items-center mt-3">
              <span className="text-sm text-slate-600">Subtotal</span>
              <span className="text-sm text-slate-600">${subtotal}</span>
            </div>
            <div className="flex justify-between items-center mt-2">
              <span className="text-sm text-slate-600">Shipping</span>
              <span className="text-sm text-slate-600">${9}</span>
            </div>
            <hr className="text-slate-200 my-3" />
            <div className="flex justify-between items-center">
              <span className="text-md font-semibold">Total</span>
              <span className="text-md font-semibold">${total}</span>
            </div>
            <button
              className="cursor-pointer w-full bg-black text-white rounded-xl px-4 py-3 mt-3"
              onClick={(e) => handlePay(e)}
            >
              Place order
            </button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Checkout;
