
const formatDate = (dateString: any) => {
  if (!dateString) return "";
  const date = new Date(dateString);

  return date.toLocaleString(undefined, {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

export {
    formatDate,
}