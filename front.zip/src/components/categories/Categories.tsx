import { Link } from "react-router-dom";
import "./Categories.css";
import Category from "./Category";
import { categories } from "../../data/categories";

const Categories = () => {

  return (
    <>
      <div className="flex justify-between items-center mt-10">
        <span className="capitalize font-semibold text-lg">
          Shop by category
        </span>
        <Link to="/shop/All">View all</Link>
      </div>
      <div className="grid grid-cols-4 md:grid-cols-12 gap-2 mt-5">
        {categories.map((category: any) => (
          <Category key={category.id} category={category} />
        ))}
      </div>
    </>
  );
};

export default Categories;
