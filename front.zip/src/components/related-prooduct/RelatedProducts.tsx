import { Link } from "react-router-dom";
import "./RelatedProducts.css";
import { products } from "../../data/products";
import Product from "../product/Product";

const RelatedProducts = (props: any) => {
  return (
    <>
      <div className="flex justify-between items-center mt-10">
        <span className="capitalize font-semibold text-lg">
          Related products
        </span>
        <Link to="/shop" className="text-sm hover:underline">
          View all
        </Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-5 mt-5">
        {products
          .filter((product: any) => {
            return (
              product.category === props.productFinded.category &&
              product.id !== props.productFinded.id
            );
          }).slice(0,3)
          .map((product: any) => (
            <Product key={product.id} product={product} />
          ))}
      </div>
    </>
  );
};

export default RelatedProducts;
