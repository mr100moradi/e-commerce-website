import { useContext, useState } from "react";
import "./SignInForm.css";
import axios from "axios";
import toast from "react-hot-toast";
import Cookies from "universal-cookie";
import Api from "../../utils/Api";
import { useNavigate } from "react-router-dom";
import { MyContext } from "../admin/MyContext";

const SignInForm = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { user, setUser } = context;

  const cookies = new Cookies();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async (e: any) => {
    e.preventDefault();

    await axios
      .post(`${Api}/user/login`, {
        email,
        password,
      })
      .then((result) => {

        cookies.set("TOKEN", result.data.token, {
          path: "/",
        });
        cookies.set("USER", result.data.user, {
          path: "/",
        });

        if (result.data.success) {
          toast.success(<div>{result.data.message}</div>);

          setEmail("");
          setPassword("");

          setUser(result.data.user);

          const userType = result.data.user.userType;

          if (userType === "employer") {
              navigate("/admin");
          }
          if (userType === "employee") {
              navigate("/");
          }
        } else {
          toast.error(<div>{result.data.message}</div>);
        }
      })
      .catch((error) => console.log(error));
  };

  return (
    <form method="post" onSubmit={(e)=>handleLogin(e)} className="space-y-6">
      <div>
        <label className="mb-2 block text-sm font-medium text-slate-700">
          Email Address
        </label>
        <input
          type="email"
          className="w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-amber-500/20 border-slate-200 focus:border-amber-500"
          placeholder="john@example.com"
          name="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div>
        <label className="mb-2 block text-sm font-medium text-slate-700">
          Password
        </label>
        <input
          type="password"
          className="w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-amber-500/20 border-slate-200 focus:border-amber-500"
          placeholder="••••••••"
          name="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <button
        type="submit"
        className="cursor-pointer w-full rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-6 py-3 font-medium text-white shadow-lg transition-all hover:shadow-xl"
      >
        Sign In
      </button>
    </form>
  );
};

export default SignInForm;
