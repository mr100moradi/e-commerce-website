import { Link } from "react-router-dom";
import "./NewArrivals.css";
import { products } from "../../data/products";
import Product from "../product/Product";


const NewArrivals = () => {

  return (
    <>
      <div className="flex justify-between items-center mt-10">
        <span className="capitalize font-semibold text-lg">New arrivals</span>
        <Link to="/shop" className="hover:underline text-sm">Shop new-in</Link>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-5 mt-5">
          {products.map((product: any) => (
            <Product key={product.id} product={product} />
          ))}
      </div>
    </>
  )
}

export default NewArrivals
