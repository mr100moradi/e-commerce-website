export type Job = {
  id: number;
  imgUrl: string;
  title: string;
};
