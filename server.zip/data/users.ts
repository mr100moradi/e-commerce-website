export type User = {
  id: number;
  name: string;
  lastName: string;
  email: string;
  password: string;
  skills: string[];
  posts: object[];
  createdAt: Date;
  updatedAt: Date;
};

export const users: User[] = [
  {
    id: 1,
    name: "M.Reza",
    lastName: "Hosseini",
    email: "mr99.moradi@gmail.com",
    password: "123456",
    skills: ["HTML", "CSS", "React"],
    posts: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updatedAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 2,
    name: "Ali",
    lastName: "Rezaei",
    email: "ali.rezaei@gmail.com",
    password: "123456",
    skills: ["Node.js", "Express", "MongoDB"],
    posts: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updatedAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 3,
    name: "Sina",
    lastName: "Kazemi",
    email: "sina.kazemi@gmail.com",
    password: "123456",
    skills: ["React", "Node.js", "Express", "MongoDB"],
    posts: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updatedAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 4,
    name: "Darius",
    lastName: "Najafi",
    email: "darius.najafi@gmail.com",
    password: "123456",
    skills: ["React", "React Native"],
    posts: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updatedAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 5,
    name: "hassaan",
    lastName: "Khalili",
    email: "hassaan.Khalili@gmail.com",
    password: "123456",
    skills: ["Python", "Machine Learning", "AI", "Data Science"],
    posts: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updatedAt: new Date("2025-09-17T00:00:00Z"),
  },
];
