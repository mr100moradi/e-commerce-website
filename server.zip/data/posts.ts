export type Post = {
  id: number;
  userId: number;
  title: string;
  file: object;
  createdAt: Date;
  updateAt: Date;
};

export const posts: Post[] = [
  {
    id: 1,
    userId: 1,
    title: "نمونه کار طراحی فرانت‌اند",
    file: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updateAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 2,
    userId: 2,
    title: "مستند معماری بک‌اند",
    file: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updateAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 3,
    userId: 3,
    title: "Case Study فول‌استک",
    file: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updateAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 4,
    userId: 4,
    title: "دمو اپلیکیشن موبایل",
    file: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updateAt: new Date("2025-09-17T00:00:00Z"),
  },
  {
    id: 5,
    userId: 5,
    title: "مدل ML نمونه",
    file: [],
    createdAt: new Date("2025-09-17T00:00:00Z"),
    updateAt: new Date("2025-09-17T00:00:00Z"),
  },
];


