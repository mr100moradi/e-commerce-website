import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./pages/home/Home";
import "./App.css";
import Shop from "./pages/shop/Shop";
import Product from "./pages/product/Product";
import { useEffect, useState } from "react";
import { MyContext, type MyContextValue } from "./pages/MyContext";
import Cart from "./pages/cart/Cart";
import { cartItems as seedCartItems, type cartItem } from "./data/cartItems";
import { favorites as seedFavorites, type favorite } from "./data/favorites";
import { compares as seedCompares, type compare } from "./data/compares";
import Checkout from "./pages/checkout/Checkout";
import UserProfile from "./pages/user/UserProfile";
import PaymentSuccess from "./pages/payment/PaymentSuccess";
import PaymentFailed from "./pages/payment/PaymentFailed";
import PaymentError from "./pages/payment/PaymentError";

function App() {

  // read cart items from local storage or seed cart items
  const loadCartItems = (): cartItem[] => {
    const saved = localStorage.getItem("cartItems");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed;
      } catch {
        return seedCartItems;
      }
    }

    // if not items in storage, read initial cartItems
    return seedCartItems;
  };
  
  // read favorites from local storage or seed favorites
  const loadFavorites = (): favorite[] => {
    const saved = localStorage.getItem("favorites");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed;
      } catch {

        // if not items in storage, read initial favorites
        return seedFavorites;
      }
    }

    // if not items in storage, read initial favorites
    return seedFavorites;
  };

  // read favorites from local storage or seed favorites
  const loadCompares = (): compare[] => {
    const saved = localStorage.getItem("compares");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return parsed;
      } catch {

        // if not items in storage, read initial favorites
        return seedCompares;
      }
    }

    // if not items in storage, read initial favorites
    return seedCompares;
  };
  

  const [cartItemsCount, setCartItemsCount] = useState<number>(0);
  const [cartItems, setCartItems] = useState<cartItem[]>(() => loadCartItems());
  const [favorites, setFavorites] = useState<favorite[]>(() => loadFavorites());
  const [compares, setCompares] = useState<compare[]>(() => loadCompares());

  const contextValue: MyContextValue = {
    cartItemsCount,
    setCartItemsCount,
    cartItems,
    setCartItems,
    favorites,
    setFavorites,
    compares,
    setCompares
  };

  const getCartItemsCount = () => {
    let count = 0;
    cartItems.map((item) => {
      count += item.number;
    });

    // const count = cartItems.reduce((acc, item) => acc + (item.number ?? 0), 0);
    setCartItemsCount(count);
  };

  useEffect(() => {
    getCartItemsCount();
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
    localStorage.setItem("favorites", JSON.stringify(favorites));
    localStorage.setItem("compares", JSON.stringify(compares));
  }, [cartItems,favorites,compares]);

  return (
    <MyContext.Provider value={contextValue}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/shop/:searchText/:categoryText" element={<Shop />} />
          
          <Route path="/product/:id" element={<Product />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/payment-success" element={<PaymentSuccess />} />
          <Route path="/payment-failed" element={<PaymentFailed />} />
          <Route path="/payment-error" element={<PaymentError />} />
          <Route path="/profile" element={<UserProfile />} />
        </Routes>
      </BrowserRouter>
    </MyContext.Provider>
  );
}

export default App;
