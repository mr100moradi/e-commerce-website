import React from "react";
import type { cartItem } from "../data/cartItems";

// export interface User {
//   _id: String;
//   name: String;
//   lastName: String;
//   email: { type: String; unique: true };
//   userType: String;
//   password: String;
//   skills: { type: [String]; default: [] };
// }

export interface favorite {
  id: string;
  productId: string;
}
export interface compare {
  id: string;
  productId: string;
}

export interface MyContextValue {
  cartItemsCount: number;
  setCartItemsCount: (value: number) => void;
  cartItems: cartItem[];
  setCartItems: (value: cartItem[]) => void;
  favorites: favorite[];
  setFavorites: (value: favorite[]) => void;
  compares: compare[];
  setCompares: (value: compare[]) => void;
  //   user: User | null;
  //   setUser: (value: User) => void;
}

export const MyContext = React.createContext<MyContextValue | undefined>({
  cartItemsCount: 0,
  setCartItemsCount: () => {},
  cartItems: [],
  setCartItems: () => {},
  favorites: [],
  setFavorites: () => {},
  compares: [],
  setCompares: () => {},
});
