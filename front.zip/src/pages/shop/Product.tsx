import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import "./Product.css"
import { faCodeCompare, faHeart } from "@fortawesome/free-solid-svg-icons"

const Product = (props:any) => {
  return (
   <div className="w-[11rem] md:w-[16rem]  border rounded-2xl overflow-hidden">
      <div className="overflow-hidden">
        <img
          src={props.product.imgUrl}
          alt=""
          className="transition-all duration-500 hover:scale-105"
        />
      </div>
      <div className="flex flex-col px-2">
        <span>{props.product.title}</span>
        <span>{props.product.price}</span>
        <div className="flex items-center gap-2 my-2">
          <button className="cursor-pointer flex items-center rounded-full border px-2 py-1 text-xs">
            <FontAwesomeIcon icon={faHeart} />
            Favorite
          </button>
          <button className="cursor-pointer flex items-center rounded-full border px-2 py-1 text-xs">
            <FontAwesomeIcon icon={faCodeCompare} />
            Compare
          </button>
        </div>
      </div>
    </div>
  )
}

export default Product
