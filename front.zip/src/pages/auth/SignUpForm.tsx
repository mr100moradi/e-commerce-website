import axios from "axios";
import "./SignUpForm.css";
import { useContext, useState } from "react";
import Api from "../../utils/Api";
import toast from "react-hot-toast";
import Cookies from "universal-cookie";
import { useNavigate } from "react-router-dom";
import { MyContext } from "../admin/MyContext";

const SignUpForm = () => {
  const context = useContext(MyContext);
  if (!context) {
    return null;
  }
  const { setUser } = context;

  const cookies = new Cookies();
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [lastName, setLastName] = useState("");
  const [userType, setUserType] = useState("employee");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleRegister = async (e: any) => {
    e.preventDefault();

    await axios
      .post(`${Api}/user/register`, {
        name,
        lastName,
        userType,
        email,
        password,
        confirmPassword,
      })
      .then((result) => {
        cookies.set("TOKEN", result.data.token, {
          path: "/",
        });
        cookies.set("USER", result.data.user, {
          path: "/",
        });

        setUser(result.data.user);

        if (result.data.success) {
          toast.success(<div>{result.data.message}</div>);

          setName("");
          setLastName("");
          setUserType("employee");
          setEmail("");
          setPassword("");
          setConfirmPassword("");

          const userType = result.data.user.userType;

          if (userType === "employer") {
            navigate("/admin");
          }
          if (userType === "employee") {
            navigate("/");
          }
        } else {
          toast.error(<div>{result.data.message}</div>);
        }
      })
      .catch((error) => console.log(error));
  };

  return (
    <form
      method="post"
      onSubmit={(e) => handleRegister(e)}
      className="space-y-6"
    >
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-2 block text-sm font-medium text-slate-700">
            First Name
          </label>
          <input
            type="text"
            className="w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-amber-500/20 border-slate-200 focus:border-amber-500"
            placeholder="John"
            name="firstName"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-2 block text-sm font-medium text-slate-700">
            Last Name
          </label>
          <input
            type="text"
            className="w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-amber-500/20 border-slate-200 focus:border-amber-500"
            placeholder="Doe"
            name="lastName"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />
        </div>
      </div>
      <div>
        <label className="mb-2 block text-sm font-medium text-slate-700">
          I am a
        </label>
        <select
          className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition-all focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20"
          name="userType"
          value={userType}
          onChange={(e) => setUserType(e.target.value)}
        >
          <option value="employee">Employee</option>
          <option value="employer">Employer</option>
        </select>
      </div>
      <div>
        <label className="mb-2 block text-sm font-medium text-slate-700">
          Email Address
        </label>
        <input
          type="email"
          placeholder="john@example.com"
          className="w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-amber-500/20 border-slate-200 focus:border-amber-500"
          name="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <div>
        <label className="mb-2 block text-sm font-medium text-slate-700">
          Password
        </label>
        <input
          type="password"
          placeholder="••••••••"
          className="w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-amber-500/20 border-slate-200 focus:border-amber-500"
          name="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <div>
        <label className="mb-2 block text-sm font-medium text-slate-700">
          Confirm Password
        </label>
        <input
          type="password"
          className="w-full rounded-xl border bg-white px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-amber-500/20 border-slate-200 focus:border-amber-500"
          placeholder="••••••••"
          name="confirmPassword"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />
      </div>
      <button
        type="submit"
        className="cursor-pointer w-full rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 px-6 py-3 font-medium text-white shadow-lg transition-all hover:shadow-xl"
      >
        Create Account
      </button>
    </form>
  );
};

export default SignUpForm;
