import "./TabItem.css";

const TabItem = (props: any) => {
  return (
    <div
      onClick={() => props.setActiveTab(props.title)}
      className="cursor-pointer capitalize text-gray-600 transition-all hover:bg-slate-100 hover:text-black rounded-xl px-3 py-2"
    >
      <span>{props.title}</span>
    </div>
  );
};

export default TabItem;
