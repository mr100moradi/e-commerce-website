import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faExclamationTriangle,
  faHome,
  faRedo,
} from "@fortawesome/free-solid-svg-icons";

const PaymentError = () => {
  
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [isLoading, setIsLoading] = useState(true);
  const [errorDetails, setErrorDetails] = useState<any>(null);

  useEffect(() => {
    // Simulate loading time for better UX
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    // Get error details from URL parameters
    const errorMessage =
      searchParams.get("errorMessage") || searchParams.get("error");
    const authority = searchParams.get("Authority");

    setErrorDetails({
      errorMessage: errorMessage || "Payment verification error",
      authority: authority || "Unknown",
      date: new Date().toLocaleDateString("en-US"),
      time: new Date().toLocaleTimeString("en-US"),
    });

    return () => clearTimeout(timer);
    
  }, [searchParams]);


  if (isLoading) {
    return (
      <div className="flex justify-center items-center w-dvw h-dvh">
        <div className="flex items-center gap-5 w-xs p-5 bg-indigo-500 text-white rounded-2xl ">
          <div className="size-7 animate-spin rounded-full border-4 border-slate-400 border-r-amber-500"></div>
          <div>
            <h2>Checking payment verification...</h2>
            <p>Please wait</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 to-orange-600"></div>

        <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-6 text-white text-3xl animate-spin">
          <FontAwesomeIcon icon={faExclamationTriangle} />
        </div>

        <h1 className="text-2xl font-bold text-orange-600 mb-4">
          Payment Verification Error
        </h1>
        <p className="text-gray-600 mb-6">
          Unfortunately, there was a problem verifying your payment. Please
          contact support.
        </p>

        <div className="bg-orange-50 rounded-xl p-4 mb-6 text-left border border-orange-200">
          <p className="text-sm text-gray-600 mb-2">
            <span className="font-semibold">Date:</span>
            <span className="ml-2">
              {errorDetails?.date} - {errorDetails?.time}
            </span>
          </p>
          <p className="text-sm text-orange-600">
            <span className="font-semibold">Status:</span>
            <span className="ml-2">Payment system error</span>
          </p>
        </div>

        <div className="space-y-3">
          <button
            className="cursor-pointer block w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 px-6 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200"
            onClick={() => navigate("/checkout")}
          >
            <FontAwesomeIcon icon={faRedo} className="mr-2" />
            Try Again
          </button>
          <button
            className="cursor-pointer block w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-xl font-semibold hover:bg-gray-200 transition-all duration-200"
            onClick={() => navigate("/")}
          >
            <FontAwesomeIcon icon={faHome} className="mr-2" />
            Back to Site
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentError;
