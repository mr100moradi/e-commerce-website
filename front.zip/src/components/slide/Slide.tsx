// Notice => bootstrap conflict with tailwind
// import "bootstrap/dist/css/bootstrap.min.css";
// import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "./Slide.css";


const Slide = (props:any) => {
  return (
    <div className="mx-1">
      <div className="slider-top-container rounded-2xl overflow-hidden">
        <img src={props.imgUrl} alt="تصویر" className="slider-top-img img-fluid" />
        {/* <div className="slider-top-text p-4">
          <p className="bold">برای یک ماجراجویی جدید آماده ای؟</p>
          <p>
            خودتو واسه مسابقه نهایی آماده کن و برنده 100 میلیون جایزه نقد شو!!
          </p>
          <div className="navbar-item">
            <a href="#">
              <div className="input-group">
                <span className="btn btn-dark">همین حالا بخر!</span>
                <div className="input-group-append">
                  <div className="bg-light rounded-left px-1 d-flex align-items-center">
                    <i className="fa fa-angle-left"></i>
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div> */}
      </div>
    </div>
  );
};

export default Slide;
