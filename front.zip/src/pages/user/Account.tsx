import { useState } from "react";
import "./Account.css";

const Account = () => {
  const [name, setName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [phone, setPhone] = useState("");

  const [saving, setSaving] = useState(false);
  const [saveResult, setSaveResult] = useState("");

  const handelSave = (e: any) => {
    e.preventDefault();

    try {
      const account = {
        name: name,
        lastName: lastName,
        email: email,
        address: address,
        city: city,
        postalCode: postalCode,
        phone: phone,
      };

      localStorage.setItem("account", JSON.stringify(account));

      setSaving(true);

      setTimeout(() => {
        setSaving(false);
        setSaveResult("save!");
      }, 2000);
    } catch (error) {
      console.log(error);
      setSaving(false);
      setSaveResult(String(error));
    }
  };

  return (
    <>
      <h2 className="capitalize font-semibold text-3xl">Profile</h2>
      <form onSubmit={(e) => handelSave(e)}>
        <div className="border rounded-xl p-5 mt-5">
          <h2 className="capitalize font-semibold text-xl">
            Contact information
          </h2>
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm text-gray-600">
                First name
              </label>
              <input
                type="text"
                className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm text-gray-600">
                Last name
              </label>
              <input
                type="text"
                className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
              />
            </div>
            <div className="sm:col-span-2">
              <label className="mb-1 block text-sm text-gray-600">Email</label>
              <input
                type="email"
                className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>
        </div>
        <div className="border rounded-xl p-5 mt-5">
          <h2 className="capitalize font-semibold text-xl">Shipping address</h2>
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="md:col-span-2">
              <label className="mb-1 block text-sm text-gray-600">
                Address
              </label>
              <input
                type="text"
                className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm text-gray-600">City</label>
              <input
                type="text"
                className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                value={city}
                onChange={(e) => setCity(e.target.value)}
              />
            </div>
            <div>
              <label className="mb-1 block text-sm text-gray-600">
                Postal code
              </label>
              <input
                type="number"
                className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                value={postalCode}
                onChange={(e) => setPostalCode(e.target.value)}
              />
            </div>
            <div className="md:col-span-2">
              <label className="mb-1 block text-sm text-gray-600">Phone</label>
              <input
                type="number"
                className="w-full rounded-xl border bg-white px-3 py-2 text-sm"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
          </div>
        </div>
        <button
          type="submit"
          className={`cursor-pointer ${
            saving ? "bg-slate-500" : "bg-black"
          } text-white rounded-lg px-2 py-1.5 mt-3`}
        >
          {saving ? "Saveing changes" : "Save changes"}
        </button>
        {saving ? (
          ""
        ) : (
          <span
            className={`text-sm ${
              saveResult === "save!" ? "text-green-700" : "text-red-700"
            } ml-3`}
          >
            {saveResult}
          </span>
        )}
      </form>
    </>
  );
};

export default Account;
