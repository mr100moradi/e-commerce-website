import { useState } from "react";
import Footer from "../../components/footer/Footer";
import Header from "../../components/header/Header";
import "./Auth.css";
import SignUpForm from "./SignUpForm";
import SignInForm from "./SignInForm";

const Auth = () => {
  const [mode, setMode] = useState<"signin" | "signup">("signin");

  return (
    <>
      <Header />
      <div className="w-md bg-white/80 border border-white/20 rounded-3xl shadow-2xl p-5 mx-auto my-10">
        {mode === "signin" && (
          <>
            <h1 className="capitalize font-bold text-3xl text-center">
              Welcome Back
            </h1>
            <p className="text-gray-700 text-center mt-2">
              Sign in to your account to continue
            </p>
          </>
        )}
        {mode === "signup" && (
          <>
            <h1 className="capitalize font-bold text-3xl text-center">
              Create Account
            </h1>
            <p className="text-gray-700 text-center mt-2">
              Join thousands of professionals and companies
            </p>
          </>
        )}
        <div className="flex justify-center">
          <div className="flex justify-center items-center gap-2 w-sm p-1 bg-gray-100 rounded-lg my-7">
            <button
              className={`cursor-pointer capitalize w-full p-1 rounded-lg font-medium ${
                mode === "signin" && "bg-white shadow-sm"
              }`}
              onClick={() => setMode("signin")}
            >
              Sign In
            </button>
            <button
              className={`cursor-pointer capitalize w-full p-1 rounded-lg font-medium ${
                mode === "signup" && "bg-white shadow-sm"
              }`}
              onClick={() => setMode("signup")}
            >
              Sign Up
            </button>
          </div>
        </div>
        {mode === "signin" && <SignInForm />}
        {mode === "signup" && <SignUpForm />}
      </div>

      <Footer />
    </>
  );
};

export default Auth;
