import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheck,
  faHome,
  faShoppingBag,
} from "@fortawesome/free-solid-svg-icons";

const PaymentSuccess = () => {
  
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [isLoading, setIsLoading] = useState(true);
  const [transactionDetails, setTransactionDetails] = useState<any>(null);

  useEffect(() => {
    // Simulate loading time for better UX
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    // Get transaction details from URL parameters
    const transId = searchParams.get("transId") || searchParams.get("RefID");
    const authority = searchParams.get("Authority");
    const amount = searchParams.get("Amount");

    setTransactionDetails({
      transId: transId || "Processing...",
      authority: authority || "Unknown",
      amount: amount || "1000",
      date: new Date().toLocaleDateString("en-US"),
      time: new Date().toLocaleTimeString("en-US"),
    });

    return () => clearTimeout(timer);

  }, [searchParams]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center w-dvw h-dvh">
        <div className="flex items-center gap-5 w-xs p-5 bg-indigo-500 text-white rounded-2xl ">
          <div className="size-7 animate-spin rounded-full border-4 border-slate-400 border-r-amber-500"></div>
          <div>
            <h2>Verifying payment status...</h2>
            <span>Please wait</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-green-500 to-green-600"></div>

        <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6 text-white text-3xl animate-bounce">
          <FontAwesomeIcon icon={faCheck} />
        </div>

        <h1 className="text-2xl font-bold text-green-600 mb-4">
          Payment Successful!
        </h1>
        <p className="text-gray-600 mb-6">
          Your order has been successfully placed and paid. Your items will be
          shipped as soon as possible.
        </p>

        <div className="bg-gray-50 rounded-xl p-4 mb-6 text-left">
          <p className="text-sm text-gray-600 mb-2">
            <span className="font-semibold">Transaction ID:</span>
            <span className="text-green-600 font-mono ml-2">
              {transactionDetails?.transId}
            </span>
          </p>
          <p className="text-sm text-gray-600">
            <span className="font-semibold">Date:</span>
            <span className="ml-2">
              {transactionDetails?.date} - {transactionDetails?.time}
            </span>
          </p>
        </div>

        <div className="space-y-3">
          <button
            className="cursor-pointer block w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-semibold hover:shadow-lg transform hover:-translate-y-1 transition-all duration-200"
            onClick={() => navigate("/")}
          >
            <FontAwesomeIcon icon={faHome} className="mr-2" />
            Back to Site
          </button>
          <button
            className="cursor-pointer block w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-xl font-semibold hover:bg-gray-200 transition-all duration-200"
            onClick={() => navigate("/shop")}
          >
            <FontAwesomeIcon icon={faShoppingBag} className="mr-2" />
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentSuccess;
