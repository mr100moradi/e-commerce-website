import { useContext, useEffect, useState } from "react";
import "./Cart.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { cartItems } from "../../data/cartItems";
import { MyContext } from "../MyContext";

const CartItem = (props: any) => {
  const context = useContext(MyContext);
  if (!context) return null;
  const { cartItems, setCartItems } = context;

  const [count, setCount] = useState(props.cartItem.number);

  const handleMinus = () => {

    if (count > 1) {
      const newCount = count - 1;
      setCount(newCount);

      // Update cart items with new count
      const updatedCartItems = cartItems?.map((item: any) => {
        if (item.productObject.id === props.cartItem.productObject.id) {
          return { ...item, number: newCount };
        }
        return item;
      });
      setCartItems(updatedCartItems);

      const price = props.cartItem.productObject.price;
      props.setSubtotal(props.subtotal - parseInt(price));
      
      props.setTotal(props.total - parseInt(price));
    }
  };

  const handlePlus = () => {

    if (count < 10) {
      const newCount = count + 1;
      setCount(newCount);

      // Update cart items with new count
      const updatedCartItems = cartItems?.map((item: any) => {
        if (item.productObject.id === props.cartItem.productObject.id) {
          return { ...item, number: newCount };
        }
        return item;
      });
      setCartItems(updatedCartItems);

      const price = props.cartItem.productObject.price;
      props.setSubtotal(props.subtotal + parseInt(price));

      props.setTotal(props.total + parseInt(price));

    }
  };

  const remove = () => {
    const cartItemList = cartItems?.filter(
      (cartItem) => cartItem.id !== props.cartItem.id
    );
    setCartItems(cartItemList);
  };

  return (
    <div className="flex justify-between items-center mt-5">
      <div className="flex items-center gap-2">
        <img
          src={props.cartItem.productObject.imgUrl}
          alt=""
          className="rounded-2xl w-24 h-24"
        />
        <div className="flex flex-col gap-1">
          <span>{props.cartItem.productObject.title}</span>
          <span>${props.cartItem.productObject.price}</span>
          <div className="inline-flex items-center rounded-full border">
            <button
              className="cursor-pointer h-9 w-9 text-lg"
              aria-label="Decrease quantity"
              onClick={() => {
                handleMinus();
              }}
            >
              −
            </button>
            <input
              min="1"
              className="h-9 w-12 border-l border-r text-center text-sm focus:outline-none"
              type="number"
              value={count}
              readOnly={true}
            />
            <button
              className="cursor-pointer h-9 w-9 text-lg"
              aria-label="Increase quantity"
              onClick={() => {
                handlePlus();
              }}
            >
              +
            </button>
          </div>
        </div>
      </div>
      <div className="flex flex-col items-end gap-2">
        <span className="text-md">${props.cartItem.productObject.price}</span>
        <button
          className="cursor-pointer bg-red-50 text-red-500 hover:bg-red-100 rounded-lg px-2 py-2"
          onClick={() => remove()}
        >
          <FontAwesomeIcon icon={faTrash} />
          Remove
        </button>
      </div>
    </div>
  );
};

export default CartItem;
