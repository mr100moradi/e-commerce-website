const axios = require("axios");

const ZARINPAL_MERCHANT = "00000000-0000-0000-0000-000000000000";

const createTransaction = async (req, res) => {
  const { amount } = req.body;

  console.log("Creating transaction for amount:", amount);

  try {
    const payload = {
      merchant_id: ZARINPAL_MERCHANT,
      amount: amount,
      description: "Test transaction",
      callback_url: "http://localhost:5000/payment-route/payment-callback",
    };

    console.log("Sending payment request:", payload);

    const { data } = await axios.post(
      "https://sandbox.zarinpal.com/pg/v4/payment/request.json",
      payload
    );

    console.log("Payment request response:", data);

    // check answer ZarinPal API
    if (data && data.data && data.data.code === 100) {
      const authority = data.data.authority;
      const payment_url = `https://sandbox.zarinpal.com/pg/StartPay/${authority}`;

      console.log("Payment URL created:", payment_url);
      res.json({
        success: true,
        payment_url,
        authority,
      });
    } else {
      const errorCode = data?.data?.code || "Unknown";
      const errorMessage = data?.errors?.message || "خطا در ایجاد تراکنش";
      console.error("Payment request failed:", errorCode, errorMessage);
      res.status(400).json({
        success: false,
        error: errorMessage,
        code: errorCode,
      });
    }
  } catch (error) {
    console.error(
      "Error creating transaction:",
      error.response?.data || error.message
    );
    res.status(500).json({
      success: false,
      error: "Error creating transaction:",
    });
  }
};

const paymentCallback = async (req, res) => {
  const { Authority, Status } = req.query;

  if (!Authority) {
    return res.status(400).send("Missing Authority parameter");
  }

  try {
    const verifyPayload = {
      merchant_id: ZARINPAL_MERCHANT,
      authority: Authority,
      amount: 1000,
    };

    const { data } = await axios.post(
      "https://sandbox.zarinpal.com/pg/v4/payment/verify.json",
      verifyPayload
    );

    // check result
    if (data && data.data && data.data.code === 100) {
      // success transaction
      const transId = data.data.ref_id;
      res.redirect(`http://localhost:5173/payment-success?transId=${transId}&Authority=${Authority}&Amount=1000`);
    } else {
      const errorCode = data?.data?.code || "Unknown";
      const errorMessage = data?.errors?.message || "Payment failed";
      console.error("Payment failed:", errorCode, errorMessage);
      res.redirect(`http://localhost:5173/payment-failed?errorCode=${errorCode}&errorMessage=${encodeURIComponent(errorMessage)}&Authority=${Authority}`);
    }
  } catch (err) {
    console.error(
      "Error in payment callback:",
      err.response?.data || err.message
    );
    res.redirect(`http://localhost:5173/payment-error?errorMessage=${encodeURIComponent('Payment verification error')}&Authority=${Authority}`);
  }
};

module.exports = {
  createTransaction,
  paymentCallback,
};
