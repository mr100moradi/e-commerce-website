export type Product = {
  id: string;
  title: string;
  imgUrl: string;
  price: string;
  category:string,
  description:string,
  stock:number,
};

import img1 from "../assets/images/trading-now/1.jpg";
import img2 from "../assets/images/trading-now/2.jpg";
import img3 from "../assets/images/trading-now/3.jpg";
import img4 from "../assets/images/trading-now/4.jpg";
import img5 from "../assets/images/trading-now/5.jpg";
import img6 from "../assets/images/trading-now/6.jpg";
import img7 from "../assets/images/trading-now/7.jpg";
import img8 from "../assets/images/trading-now/8.jpg";
import img9 from "../assets/images/trading-now/9.jpg";
import img10 from "../assets/images/trading-now/10.jpg";

// categories =>  Shoes, Bags, Accessories, Clothing, Electronics, Home

export const products: Product[] = [
  {
    id: "1",
    imgUrl: img1,
    title: "Sample Product 1",
    price: "19",
    category:"Shoes",
    description:"Demo description for product 1.",
    stock:10,
  },
  {
    id: "2",
    imgUrl: img2,
    title: "Sample Product 2",
    price: "30",
    category:"Shoes",
    description:"Demo description for product 2.",
    stock:10,
  },
  {
    id: "3",
    imgUrl: img3,
    title: "Sample Product 3",
    price: "45",
    category:"Shoes",
    description:"Demo description for product 3.",
    stock:10,
  },
  {
    id: "4",
    imgUrl: img4,
    title: "Sample Product 4",
    price: "55",
    category:"Bags",
    description:"Demo description for product 4.",
    stock:10,
  },
  {
    id: "5",
    imgUrl: img5,
    title: "Sample Product 5",
    price: "60",
    category:"Bags",
    description:"Demo description for product 5.",
    stock:10,
  },
  {
    id: "6",
    imgUrl: img6,
    title: "Sample Product 6",
    price: "65",
    category:"Accessories",
    description:"Demo description for product 6.",
    stock:10,
  },
  {
    id: "7",
    imgUrl: img7,
    title: "Sample Product 7",
    price: "70",
    category:"Accessories",
    description:"Demo description for product 7.",
    stock:10,
  },
  {
    id: "8",
    imgUrl: img8,
    title: "Sample Product 8",
    price: "75",
    category:"Clothing",
    description:"Demo description for product 8.",
    stock:10,
  },
  {
    id: "9",
    imgUrl: img9,
    title: "Sample Product 9",
    price: "80",
    category:"Clothing",
    description:"Demo description for product 9.",
    stock:10,
  },
  {
    id: "10",
    imgUrl: img10,
    title: "Sample Product 10",
    price: "85",
    category:"Electronics",
    description:"Demo description for product 10.",
    stock:10,
  },
];
